﻿using System.Collections.Generic;
using System.Globalization;
using System;

namespace The_Cinema
{
    class Cinema
    {
        string genre;
        string name;
        string description;
        TimeSpan runtime;
        double ticket;

        public Cinema()
        {

        }

        public Cinema(string genre, string name, string description, TimeSpan runtime, double ticket)
        {
            this.Genre = genre;
            this.Name = name;
            this.Desc = description;
            this.Runtime = runtime;
            this.Ticket = ticket;
        }

        public string Genre
        {
            get { return genre; }
            set { genre = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Desc
        {
            get { return description; }
            set { description = value; }
        }

        public TimeSpan Runtime
        {
            get { return runtime; }
            set { runtime = value; }
        }

        public double Ticket
        {
            get { return ticket; }
            set { ticket = value; }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            List<Cinema> cinema = new List<Cinema>();
            int option = 0;
            int limit = 0;
            Cinema films;
            bool filmFull = false;
            int purchaseTicket = 0;
            string clientOrEmployee = " ";

            Console.Write("Are You A Client or an Employee: ");
            clientOrEmployee = Console.ReadLine();

            if (String.Equals(clientOrEmployee, "Client", StringComparison.OrdinalIgnoreCase))
            {
                do
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("Welcome To Galaxy Cinemas");
                    Console.WriteLine("-------------------------------------------");
                    Console.WriteLine("1) Display Movies");
                    Console.WriteLine("2) Purchase Ticket For Film");
                    Console.WriteLine("3) Buying Snacks");
                    Console.WriteLine("4) Exit The Application");
                    Console.Write("Select Output: ");

                    while (!int.TryParse(Console.ReadLine(), out option) || option < 1 || option > 4)
                    {
                        Console.WriteLine("Please Enter Valid Input");
                    }

                    switch (option)
                    {
                        case 1:
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("******************************************");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("1) Display Movies");
                            Console.WriteLine("-------------------------------------------");
                            Console.WriteLine("Genres\t\tName\t\tDescription\tRuntime\tTicketPrice$");

                            foreach (Cinema item in cinema)
                            {
                                Console.WriteLine($"{item.Genre}\t\t{item.Name}\t\t{item.Desc}\t\t{item.Runtime}\t\t{item.Ticket}");
                            }

                            break;

                        case 2:
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("******************************************");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("2) Purchase Ticket For Film");
                            Console.WriteLine("-------------------------------------------");
                            Console.WriteLine("What Movie do you want to watch");
                            films = new Cinema();

                        jump:
                            try
                            {
                                films.Name = Console.ReadLine();
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                                goto jump;
                            }

                            Console.WriteLine("How Many Tickets Do You Want? ");

                        jump0:
                            try
                            {
                                purchaseTicket = Convert.ToInt32(Console.ReadLine());
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                                goto jump0;
                            }

                            Console.WriteLine($"Tickets for {films.Name} has been purchased ");
                            break;

                        case 3:
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("******************************************");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("3) Buying Snacks");
                            Console.WriteLine("-------------------------------------------");
                            Console.WriteLine("What Snacks do you want");
                            Console.WriteLine("1. Popcorn\n2.Soda\n3.Nachos\n4.Hotdog");
                            Console.WriteLine("Insert Snack Number: ");

                        jump4:
                            try
                            {
                                int snacks = Convert.ToInt32(Console.ReadLine());
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.Message);
                                goto jump4;
                            }

                            Console.WriteLine($"Snacks has been purchased ");
                            break;

                        case 4:
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("Goodbye Take Care");
                            Environment.Exit(0);
                            break;
                    }
                    Console.WriteLine("Press any key");
                    Console.ReadLine();
                    Console.Clear();
                } while (option != 4);
            }
            else if (String.Equals(clientOrEmployee, "Employee", StringComparison.OrdinalIgnoreCase))
            {
                do
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("Welcome To Galaxy Cinemas");
                    Console.WriteLine("-------------------------------------------");
                    Console.WriteLine("1) Create Movies");
                    Console.WriteLine("2) Display Movies");
                    Console.WriteLine("3) Exit The Application");
                    Console.Write("Select Output: ");

                    while (!int.TryParse(Console.ReadLine(), out option) || option < 1 || option > 3)
                    {
                        Console.WriteLine("Please Enter Valid Input");
                    }

                    switch (option)
                    {
                        case 1:
                            if (filmFull == false)
                            {
                                films = new Cinema();
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine("******************************************");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                Console.WriteLine("1) Create Movies");
                                Console.WriteLine("-------------------------------------------");

                                while (string.IsNullOrEmpty(films.Genre))
                                {
                                    Console.Write("Enter Movie Genre: ");
                                    films.Genre = Console.ReadLine();
                                }

                                while (string.IsNullOrEmpty(films.Name))
                                {
                                    Console.Write("Enter Movie Name: ");
                                    films.Name = Console.ReadLine();
                                }

                                while (string.IsNullOrEmpty(films.Desc))
                                {
                                    Console.Write("Enter Movie Description(short): ");
                                    films.Desc = Console.ReadLine();
                                }

                            jump1:
                                Console.Write("Enter Movie's Runtime(hh:mm:ss): ");
                                string input = Console.ReadLine();
                                try
                                {
                                    films.Runtime = TimeSpan.ParseExact(input, @"h\:mm\:ss", CultureInfo.InvariantCulture);
                                }
                                catch (FormatException ex)
                                {
                                    Console.WriteLine("Invalid format. Please enter the runtime in the format hh:mm:ss.");
                                    goto jump1;
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                    goto jump1;
                                }

                            jump2:
                                Console.Write("Enter Movie's Price: ");
                                try
                                {
                                    films.Ticket = double.Parse(Console.ReadLine());
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex.Message);
                                    goto jump2;
                                }

                                Console.WriteLine("Movie Has Been Successfully Created!");
                                limit++;
                                cinema.Add(films);

                                if (limit == 20)
                                {
                                    filmFull = true;
                                }
                            }
                            else
                            {
                                Console.WriteLine("Movie Creation Has Reached its limit");
                            }
                            break;

                        case 2:
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("******************************************");
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("2) Display Movies");
                            Console.WriteLine("-------------------------------------------");
                            Console.WriteLine("Genres\t\tName\t\tDescription\tRuntime\tTicketPrice$");

                            foreach (Cinema item in cinema)
                            {
                                Console.WriteLine($"{item.Genre}\t\t{item.Name}\t\t{item.Desc}\t\t{item.Runtime}\t\t{item.Ticket}");
                            }

                            break;

                        case 3:
                            Console.ForegroundColor =  ConsoleColor.Cyan;
                            Console.WriteLine("Goodbye Take Care");
                            Environment.Exit(0);
                            break;
                    }
                    Console.WriteLine("Press any key");
                    Console.ReadLine();
                    Console.Clear();
                } while (option != 3);
            }
            else
            {
                Console.WriteLine("Sorry Incorrect Input. Try Again");
            }
        }
    }
}
