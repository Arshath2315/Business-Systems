public interface IBuilder {

    void setColor();
    void setCooktime();
    void setSides();
    void setTaste();
    void setOcean();
    Fish getFish();
}
